# flashlight 0.2.0

* New functionality

- Added variable contribution breakdown for single observations.

* Interface change

- Removed `zero_counts` argument in `plot_counts`.

* Bug fixes

- `zero_counts` in `plot_counts` and `plot.light_effects` had no effect for single flashlights with no "by" variable. This is fixed.


