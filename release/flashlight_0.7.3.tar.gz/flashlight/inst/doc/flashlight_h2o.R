## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE,
  fig.width = 7,
  fig.height = 6
)

## ----setup--------------------------------------------------------------------
library(dplyr)
library(MetricsWeighted)
library(flashlight)
library(caret)
library(h2o)

h2o.init()
h2o.no_progress()

## -----------------------------------------------------------------------------
data(cars)
str(cars)

## -----------------------------------------------------------------------------
undo_dummies <- function(df, cols) {
  factor(data.matrix(df[, cols]) %*% seq_along(cols), labels = cols)
}

no_yes <- function(x) {
  factor(x, 0:1, c("no", "yes"))
}

# Prepare data
cars <- cars %>% 
  mutate(Price = log(Price),
         Mileage = log(Mileage),
         Made = undo_dummies(., c("Buick", "Cadillac", "Chevy", "Pontiac", "Saab", "Saturn"))) %>% 
  mutate_at(c("Cruise", "Sound", "Leather"), no_yes)

# Response and covariables
y <- "Price"
x <- c("Cylinder", "Doors", "Cruise", "Sound", "Leather", "Mileage", "Made")

# Data split
set.seed(1)
idx <- c(createDataPartition(cars[[y]], p = 0.7, list = FALSE))
tr <- cars[idx, c(y, x)]
te <- cars[-idx, c(y, x)]

# Fit the models
fit_lm <- h2o.glm(x, y, as.h2o(tr))
fit_rf <- h2o.randomForest(x, y, as.h2o(tr))

## -----------------------------------------------------------------------------
pred_fun <- function(mod, X) as.vector(unlist(h2o.predict(mod, as.h2o(X))))
fl_lm <- flashlight(model = fit_lm, label = "lm", predict_function = pred_fun)
fl_rf <- flashlight(model = fit_rf, label = "rf", predict_function = pred_fun)

fls <- multiflashlight(list(fl_lm, fl_rf), y = y, data = te, 
                       metrics = list(RMSE = rmse, `R-Squared` = r_squared))

## -----------------------------------------------------------------------------
light_performance(fls) %>% 
  plot(fill = "darkred")

## -----------------------------------------------------------------------------
imp <- light_importance(fls) 
plot(imp, fill = "darkred")

## -----------------------------------------------------------------------------
# Individual conditional expectations (ICE). Using a seed guarantees the same observations across models
light_ice(fls, v = "Cylinder", n_max = 100, seed = 54) %>% 
  plot(alpha = 0.1)

# Partial dependence profiles
light_profile(fls, v = "Cylinder") %>% 
  plot()

light_profile(fls, v = "Cylinder", by = "Leather") %>% 
  plot()

# Accumulated local effects
light_profile(fls, v = "Cylinder", type = "ale") %>% 
  plot()

# M-Plots
light_profile(fls, v = "Mileage", type = "predicted") %>% 
  plot()

# Response profiles, prediction profiles, partial dependence in one
eff <- light_effects(fls, v = "Cylinder") 
eff %>% 
  plot() %>% 
  plot_counts(eff, alpha = 0.3)

## -----------------------------------------------------------------------------
light_interaction(fls, v = most_important(imp, 3), pairwise = TRUE, 
                           n_max = 30, seed = 63) %>% 
  plot(fill = "darkred")

## -----------------------------------------------------------------------------
light_global_surrogate(fls) %>% 
  plot()

## -----------------------------------------------------------------------------
h2o.shutdown()

