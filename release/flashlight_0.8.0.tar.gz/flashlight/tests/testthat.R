library(testthat)
library(flashlight)

test_check("flashlight")
